# nodeProperty
A Web local service that get properties data from Zoopla and RightMove.

