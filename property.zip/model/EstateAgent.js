// Constructor
function EstateAgent(id,name,postcode) {
  this.id = id;
  this.name = name;
  this.postcode = postcode;
}

// export the class
module.exports = EstateAgent;