// Constructor
function PropertyType(id,type) {
  this.id = id;
  this.type = type;
}

// export the class
module.exports = PropertyType;