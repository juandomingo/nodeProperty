// Constructor
function Postcode(id,name) {
  this.id = id;
  this.name = name;
}

// export the class
module.exports = Postcode;